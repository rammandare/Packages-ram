# This is a Chef Infra attributes file. It can be used to specify default and override
# attributes to be applied to nodes that run this cookbook.

# Set a default name
default['starter_name'] = 'Sam Doe'

# For further information, see the Chef documentation (https://docs.chef.io/attributes).
